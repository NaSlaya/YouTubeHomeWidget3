# YouTube Home Widget

Complete Android project, correctly structured for GitHub Actions cloud builds.

Top-level files/folders must remain exactly as provided:
- .github/workflows/build.yml
- app/
- build.gradle.kts
- gradle.properties
- settings.gradle.kts

GitHub Actions builds the debug APK with JDK 17, Gradle 8.11.1, Android Gradle Plugin 8.10.1, compileSdk/targetSdk 36.

The current widget is a functional starter widget that opens YouTube. It does not access the private personalised YouTube Home recommendation algorithm.
